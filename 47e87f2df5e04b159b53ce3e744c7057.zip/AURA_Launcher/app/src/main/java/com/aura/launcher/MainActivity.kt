package com.aura.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent { AuraHome() }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuraHome() {
  val pm = androidx.compose.ui.platform.LocalContext.current.packageManager
  val apps = remember {
    pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName)!=null }
      .map { AppInfo(it.loadLabel(pm).toString(), it.packageName, it.loadIcon(pm)) }
      .sortedBy { it.name }
  }
  var query by remember { mutableStateOf("") }
  val filtered = apps.filter { it.name.contains(query, true) }
  Column(Modifier.fillMaxSize().background(Color(0xFF0A0A0F))) {
    OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(16.dp),placeholder={Text("Rechercher…",color=Color.White)},colors=TextFieldDefaults.outlinedTextFieldColors(textColor=Color.White,cursorColor=Color.White,focusedBorderColor=Color(0xFF7C4DFF)))
    LazyVerticalGrid(columns=GridCells.Fixed(4),modifier=Modifier.fillMaxSize().padding(8.dp)) {
      items(filtered){ app ->
        Column(Modifier.padding(10.dp).clickable { pm.getLaunchIntentForPackage(app.pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { androidx.compose.ui.platform.LocalContext.current.startActivity(it) } },horizontalAlignment=Alignment.CenterHorizontally) {
          androidx.compose.foundation.Image(app.icon, contentDescription=app.name, modifier=Modifier.size(52.dp))
          Spacer(Modifier.height(6.dp)); Text(app.name,color=Color.White,fontSize=12.sp,maxLines=1)
        }
      }
    }
  }
}
data class AppInfo(val name:String,val pkg:String,val icon:android.graphics.drawable.Drawable)
