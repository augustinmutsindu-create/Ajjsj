# AURA Launcher

Lanceur Android moderne avec écran d’accueil, tiroir d’applications, recherche instantanée et animations Material 3.

## Installation
1. Ouvrir le dossier dans Android Studio.
2. Laisser Gradle synchroniser.
3. Lancer sur un appareil ou émulateur Android 8.0+.
4. Après installation : Paramètres > Applications > Applications par défaut > Application d’accueil > AURA Launcher.

## Prochaines étapes
- Widgets et dock intelligent
- Gestes personnalisés
- Fonds d’écran animés
- Thèmes Material You
- Verrouillage d’applications
